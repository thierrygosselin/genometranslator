# Read package-native genomic data ---------------------------------------------

#' @name read_genome
#' @title Read package-native genomic data
#' @description Read GDS, Arrow/Parquet, legacy FST/RAD, TSV, wide genomic
#' tables, or tidy genomic tables. Tabular inputs are normalized with the
#' internal \code{as_tidy_genome()} helper.

#' The function uses \code{\link[arrow]{read_parquet}} or
#' CoreArray Genomic Data Structure (\href{https://github.com/zhengxwen/gdsfmt}{GDS})
#' file system.
#'
#'
#' Used internally in \href{https://github.com/thierrygosselin/genometranslator}{genometranslator}
#' and \href{https://github.com/thierrygosselin/assigner}{assigner}
#' and might be of interest for users.


#' @param data A file in the working directory ending with .arrow.parquet or .gds,
#' a TSV or legacy RAD/FST file, or an existing wide/tidy genomic table.
#' @param columns (optional) For arrow.parquet file.
#' Column names to read.
#' The default is to read all all columns.
#' Default: \code{columns = NULL}.
#' @param allow.dup (optional, logical) To allow the opening of a GDS file with
#' read-only mode when it has been opened in the same R session.
#' Default: \code{allow.dup = FALSE}.
#' @param check (optional, logical) Verify that GDS number of samples and markers
#' match.
#' Default: \code{check = TRUE}.
#' @param import.metadata Logical. Retain columns in addition to the standard
#' genomic columns when normalizing tabular input.
#' Default: \code{import.metadata = TRUE}.
#' @param verbose (optional, logical) \code{verbose = TRUE} to be chatty
#' during execution.
#' Default: \code{verbose = FALSE}.

#' @details For GDS file system, \strong{read_genome} will open the GDS connection file
#' set the filters (variants and samples) based on the info found in the file.

#' @return A tidy genomic data frame or
#' GDS object (with read/write permissions) in the global environment.
#' @export
#' @rdname read_genome
#' @seealso
#' \href{https://github.com/apache/arrow/}{arrow}
#' \href{https://github.com/zhengxwen/gdsfmt}{GDS}
#' \code{\link{read_genome}}

#' @author Thierry Gosselin \email{thierrygosselin@@icloud.com}
#' @examples
#' \dontrun{
#' require(SeqArray)
#' shark <- genometranslator::read_genome(data = "data.shark.gds")
#' turtle <- genometranslator::read_genome(data = "data.turtle.arrow.parquet")
#' }

read_genome <- function(
    data,
    columns = NULL,
    allow.dup = FALSE,
    check = TRUE,
    import.metadata = TRUE,
    verbose = FALSE
) {

  # Common startup -------------------------------------------------------------
  .start <- tgbase::startup(
    package = "genometranslator",
    f.name = "read_genome",
    verbose = verbose
  )
  on.exit(tgbase::teardown(.start), add = TRUE)

  # detect format---------------------------------------------------------------
  data.type <- detect_genomic_format(data)

  # An existing GDS connection needs no file import.
  if (identical(data.type, "SeqVarGDSClass")) return(data)

  # arrow parquet file ---------------------------------------------------------
  if ("arrow.parquet" %in% data.type) {
    # for some results, arrow doesn't like having option B only when col_select
    # is NULL from the function call...
    if (is.null(columns)) { #option A
      data <- arrow::read_parquet(file = data)
    } else { #option B
      data <- arrow::read_parquet(file = data, col_select = columns)
    }
    return(as_tidy_genome(data, import.metadata = import.metadata))
  }

  # Legacy FST/RAD file --------------------------------------------------------
  if (identical(data.type, "fst.file")) {
    tgbase::check_package(package = "fst")
    data <- fst::read_fst(path = data, as.data.table = FALSE)
    return(as_tidy_genome(data, import.metadata = import.metadata))
  }

  # TSV or in-memory tabular input ---------------------------------------------
  if (identical(data.type, "tbl_df")) {
    if (is.character(data) && length(data) == 1L) {
      data <- readr::read_tsv(
        file = data,
        col_types = readr::cols(.default = readr::col_character())
      )
    }
    return(as_tidy_genome(data, import.metadata = import.metadata))
  }



  # GDS file -------------------------------------------------------------------
  if ("gds.file" %in% data.type) {
    if (verbose) message("Opening GDS file connection")

    seq_open_temp <- function(data, allow.dup) {
      SeqArray::seqOpen(gds.fn = data, readonly = allow.dup, allow.duplicate = allow.dup)
    }#End seq_open_temp

    safe_seq_open <- purrr::safely(.f = seq_open_temp)

    data.safe <- safe_seq_open(data, allow.dup)

    if (is.null(data.safe$error)) {
      data <- data.safe$result
    } else {
      temp <- gdsfmt::openfn.gds(filename = data, readonly = FALSE, allow.fork = FALSE, allow.duplicate = TRUE)
      if (gdsfmt::get.attr.gdsn(temp$root)$FileFormat == "SNP_ARRAY") {
        gdsfmt::closefn.gds(gdsfile = temp)
        tgbase::check_package(package = "SeqArray", cran = FALSE, bioc = TRUE)
        temp.name <- stringi::stri_join("radiator_temp_", data)
        message("The input file is a SNP GDS file, conversion using SeqArray::seqSNP2GDS")
        SeqArray::seqSNP2GDS(data, temp.name)
        data <- SeqArray::seqOpen(gds.fn = temp.name, readonly = allow.dup, allow.duplicate = allow.dup)
        message("SeqArray GDS file generated: ", temp.name)
      }
    }

    s <- extract_individuals_metadata(
      gds = data,
      ind.field.select = "INDIVIDUALS",
      whitelist = TRUE
    ) %$%
      INDIVIDUALS
    m <- extract_markers_metadata(
      gds = data,
      markers.meta.select = "VARIANT_ID",
      whitelist = TRUE
    ) %$%
      VARIANT_ID
    if (verbose) message("Setting filters to:")
    if (verbose) message("    number of samples: ", length(s))
    if (verbose) message("    number of markers: ", length(m))

    SeqArray::seqSetFilter(object = data,
                           variant.id = m,
                           sample.id = as.character(s),
                           verbose = FALSE)

    # Checks--------------------------------------------------------------------
    if (check) {
      check <- SeqArray::seqGetFilter(data)
      if (length(check$sample.sel[check$sample.sel]) != length(s)) {
        rlang::abort("Number of samples don't match, contact author")
      }
      if (length(check$variant.sel[check$variant.sel]) != length(m)) {
        rlang::abort("Number of markers don't match, contact author")
      }
    }
    return(data)
  }#End gds.file

  rlang::abort("Input format is not supported by read_genome().")
}#End read_genome


# Normalize a wide or tidy genomic table ---------------------------------------
as_tidy_genome <- function(data, import.metadata = FALSE) {
  data %<>% dplyr::rename(STRATA = tidyselect::any_of("POP_ID"))

  if (rlang::has_name(data, "LOCUS") && !rlang::has_name(data, "MARKERS")) {
    data %<>% dplyr::rename(MARKERS = LOCUS)
  }

  if (!"MARKERS" %in% colnames(data) && !"LOCUS" %in% colnames(data)) {
    grouping.cols <- "INDIVIDUALS"
    if (rlang::has_name(data, "STRATA")) {
      grouping.cols <- c("STRATA", "INDIVIDUALS")
    }
    data %<>%
      tgbase::trans_long(
        x = .,
        cols = grouping.cols,
        names_to = "MARKERS",
        values_to = "GT",
        variable_factor = FALSE
      )
  }

  if (!import.metadata) {
    want <- c(
      "STRATA", "INDIVIDUALS", "MARKERS", "CHROM", "LOCUS", "POS",
      "GT", "GT_VCF_NUC", "GT_VCF", "ALT_DOSAGE"
    )
    data %<>% dplyr::select(tidyselect::any_of(want))
  }

  if (rlang::has_name(data, "MARKERS")) {
    data$MARKERS %<>% clean_markers_names(.)
  }
  data$INDIVIDUALS %<>% clean_ind_names(.)
  if (rlang::has_name(data, "STRATA")) {
    data$STRATA %<>% clean_pop_names(.)
  }

  dplyr::ungroup(data)
}


#' @name write_genome
#' @title Write tidy genomic data file or close GDS file
#' @description For tidy genomic datasets, the function provides a
#' fast way to write a \code{.arrow.parquet} file from Apache.
#'
#'
#' When the object is a CoreArray Genomic Data Structure
#' (\href{https://github.com/zhengxwen/gdsfmt}{GDS}) file system, the function
#' \strong{close the connection with the GDS file}. Before doing so it sets the
#' filters (variants and samples) based on the info found in the file.
#'
#' Used internally in \href{https://github.com/thierrygosselin/genometranslator}{genometranslator}
#' and \href{https://github.com/thierrygosselin/assigner}{assigner}
#' and might be of interest for users.

#' @param data An object in the global environment: tidy genomic dataset
#' or GDS connection file

#' @param filename Name of the Arrow/Parquet file written for tabular data.
#' The argument is not used when closing a GDS connection.

#' @param internal (optional, logical) This is used inside radiator internal code and it stops
#' from writing the file.
#' Default: \code{internal = FALSE}.

#' @param write.message (optional, character) Print a message in the console
#' after writing file.
#' With \code{write.message = NULL}, nothing is printed in the console.
#' Default: \code{write.message = "standard"}. This will print
#' \code{message("File written: ", basename(filename))}.

#' @param verbose (optional, logical) \code{verbose = TRUE} to be chatty
#' during execution.
#' Default: \code{verbose = FALSE}.

#' @return A file written in the working directory or nothing if it's a GDS connection file.
#' @export
#' @rdname write_genome
#'
#'
#' @author Thierry Gosselin \email{thierrygosselin@@icloud.com}
#' @seealso
#' \href{https://arrow.apache.org}{appache arrow}
#'
#' \href{https://github.com/zhengxwen/gdsfmt}{GDS}
#'
#' \code{\link{read_genome}}
#'
#' @examples
#' \dontrun{
#' require(SeqArray)
#' genometranslator::write_genome(data = tidy.data, filename = "data.shark.arrow.parquet")
#' genometranslator::write_genome(data = gds.object)
#' }


write_genome <- function(
    data,
    filename = NULL,
    internal = FALSE,
    write.message = "standard",
    verbose = FALSE
) {

  if (!internal) {
    # detect format---------------------------------------------------------------
    data.type <- class(data)

    # GDS closing connection and setting filters
    if ("SeqVarGDSClass" %in% data.type) {
      # samples
      s <- extract_individuals_metadata(
        gds = data,
        ind.field.select = "INDIVIDUALS",
        whitelist = TRUE
      ) %$%
        INDIVIDUALS

      # markers
      m <- extract_markers_metadata(
        gds = data,
        markers.meta.select = "VARIANT_ID",
        whitelist = TRUE
      ) %$%
        VARIANT_ID

      if (verbose) message("Setting filters to:")
      if (verbose) message("    number of samples: ", length(s))
      if (verbose) message("    number of markers: ", length(m))
      # ?SeqArray::seqSetFilter
      gds.filename <- data$filename
      SeqArray::seqClose(data)
      data <- SeqArray::seqOpen(gds.fn = gds.filename, readonly = FALSE, allow.duplicate = FALSE)
      SeqArray::seqSetFilter(object = data,
                             variant.id = m,
                             sample.id = as.character(s),
                             verbose = verbose)
      if (verbose) message("Closing connection with GDS file:\n", basename(gds.filename))
      SeqArray::seqClose(data)
      return(gds.filename)
    }

    # using arrow parquet
    if (is.null(filename)) rlang::abort("A filename must be provided")

    file.type <- stringi::stri_extract(
      str = filename,
      regex = "\\.[^\\.]*$"
    )

    # check for .rad file ending
    if (".rad" %in% file.type) {
      message("fst file format deprecated, see function doc")
      message("Changing .rad to .arrow.parquet")
      filename <- stringi::stri_sub_replace(str = filename, from = -4, to = -1, replacement = ".arrow.parquet")
      file.type <- ".parquet"
    }

    if (!".parquet" %in% file.type) {
      rlang::abort("filename with .arrow.parquet must be provided")
    }

    if (verbose) cli::cli_progress_step(msg = "Writing arrow parquet tidy dataset...")

    # writing arrow parquet file
    tibble::as_tibble(data) %>%
      arrow::write_parquet(x = ., sink = filename)

    if (verbose) cli::cli_progress_done()

    if (!is.null(write.message) && verbose) {
      if (write.message == "standard") {
        message("File written: ", basename(filename))
      } else {
        write.message
      }
    }
  }

}#End write_genome
