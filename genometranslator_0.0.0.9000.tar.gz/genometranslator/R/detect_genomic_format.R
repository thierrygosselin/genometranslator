# Detect detect_genomic_format

#' @name detect_genomic_format
#' @title Used internally in radiator to detect the file format
#' @description Detect the file format of genomic data set.
#' @param data 15 options for input: VCFs (SNPs or Haplotypes,
#' to make the vcf population ready),
#' PLINK 1 (bed, ped, and tped), PLINK 2 (pgen), stacks haplotype file,
#' genind (library(adegenet)),
#' genlight (library(adegenet)), gtypes (library(strataG)), genepop, DArT,
#' and a data frame in long/tidy or wide format. To verify that radiator detect
#' your file format use \code{\link{detect_genomic_format}} (see example below).
#' New addition to radiator: the Apache Parquet columnar storage file format that
#' will replace the fst (Lightning Fast Serialiation) format.
#' Documented in \strong{Input genomic datasets} of \code{\link{tidy_genome}}.

#' @param guess (character) In development, guess faster the type of file.
#' Default: \code{guess = NULL}.

#' @return One of these file format:
#' \itemize{
#' \item tbl_df: for a data frame
#' \item genind: for a genind object
#' \item genlight: for a genlight object
#' \item gtypes: for a gtypes object
#' \item vcf.file: for a vcf file
#' \item plink.tped.file: for a plink tped file
#' \item plink.bed.file: for a plink bed file
#' \item plink.ped.file: for a plink ped file
#' \item plink.pgen.file: for a PLINK 2 pgen file
#' \item genepop.file: for a genepop file
#' \item haplo.file: for a stacks haplotypes file
#' \item fstat.file: for a fstat file
#' \item dart: for a DArT file
#' \item fst.file: for a file ending with .rad
#' \item SeqVarGDSClass: for SeqArray GDS file.
#' \item arrow parquet: for a Apache Parquet columnar storage file format,
#' used by arrow R package.
#' }

#' @rdname detect_genomic_format
# @keywords internal
#' @export
#' @examples
#' \dontrun{
#' #To verify your file is detected by radiator as the correct format:
#' genometranslator::detect_genomic_format(data = "populations.snps.vcf")
#' }
#' @author Thierry Gosselin \email{thierrygosselin@@icloud.com}

detect_genomic_format <- function(data, guess = NULL){
  data.type <- NULL # in case we don't find the format

  if (is.null(guess)) {
    if (!is.vector(data)) {
      if (tibble::has_name(data, "INDIVIDUALS")) {
        data.type <- "tbl_df" #"df.file"
      } else {
        data.type <- class(data)[1]
        if (!data.type %in% c("genind", "genlight", "gtypes", "SeqVarGDSClass")) rlang::abort("Input file not recognised")
      }
      return(data.type)
    } # not vector
    if (is.vector(data)) {
      path.lower <- tolower(as.character(data[[1]]))

      # Detect binary and text PLINK files before reading their first line.
      # Reading a binary BED/PGEN as text is both unnecessary and unreliable.
      plink.companions <- function(prefix, extensions, label) {
        candidates <- vapply(
          extensions,
          function(ext) any(file.exists(paste0(prefix, ext))),
          logical(1)
        )
        if (!all(candidates)) {
          missing <- extensions[!candidates]
          rlang::abort(paste0(
            "Missing ", label, " companion file(s): ",
            paste(missing, collapse = ", ")
          ))
        }
      }

      if (grepl("\\.pgen$", path.lower)) {
        prefix <- sub("\\.pgen$", "", as.character(data[[1]]), ignore.case = TRUE)
        if (!file.exists(paste0(prefix, ".psam"))) {
          rlang::abort("Missing PLINK 2 companion file: .psam")
        }
        if (!file.exists(paste0(prefix, ".pvar")) &&
            !file.exists(paste0(prefix, ".pvar.zst"))) {
          rlang::abort("Missing PLINK 2 companion file: .pvar or .pvar.zst")
        }
        return("plink.pgen.file")
      }
      if (grepl("\\.bed$", path.lower)) {
        prefix <- sub("\\.bed$", "", as.character(data[[1]]), ignore.case = TRUE)
        plink.companions(prefix, c(".bim", ".fam"), "PLINK BED")
        return("plink.bed.file")
      }
      if (grepl("\\.tped$", path.lower)) {
        prefix <- sub("\\.tped$", "", as.character(data[[1]]), ignore.case = TRUE)
        plink.companions(prefix, ".tfam", "PLINK TPED")
        return("plink.tped.file")
      }
      if (grepl("\\.ped$", path.lower)) {
        prefix <- sub("\\.ped$", "", as.character(data[[1]]), ignore.case = TRUE)
        plink.companions(prefix, ".map", "PLINK PED")
        return("plink.ped.file")
      }

      data.type <- suppressWarnings(readLines(con = data, n = 1L))
      file.ending <- stringi::stri_sub(str = data, from = -4, to = -1)

      # Specifics with gz file ...
      if (stringi::stri_detect_fixed(str = file.ending, pattern = "gz")) {
        file.ending <- stringi::stri_sub(str = data, from = -7, to = -4)
      }

      # VCF --------------------------------------------------------------------
      # if (identical(data.type, "##fileformat=VCF") || file.ending == ".vcf") {
      if (stringi::stri_detect_fixed(str = data.type, pattern = "##fileformat=VCF") || file.ending == ".vcf") {
        data.type <- "vcf.file"
        # message("File type: VCF")
        return(data.type)
      } #End VCF


      # TIBBLE -----------------------------------------------------------------
      if (stringi::stri_detect_fixed(str = data.type, pattern = "POP_ID") | stringi::stri_detect_fixed(str = data.type, pattern = "INDIVIDUALS") | stringi::stri_detect_fixed(str = data.type, pattern = "MARKERS") | stringi::stri_detect_fixed(str = data.type, pattern = "LOCUS")) {
        data.type <- "tbl_df" #"df.file"
        # message("File type: data frame of genotypes")
        return(data.type)
      }
      if (stringi::stri_detect_fixed(str = data.type, pattern = "Catalog")) {
        data.type <- "haplo.file"
        return(data.type)
      }
      if (file.ending == ".gen") {
        data.type <- "genepop.file"
        return(data.type)
      }
      if (file.ending == ".dat") {
        data.type <- "fstat.file"
        return(data.type)
      }

      # .rad, fst file or gds --------------------------------------------------
      if (TRUE %in% (c(".rad", ".gds") %in% file.ending)) {
        if (stringi::stri_detect_fixed(str = data.type, pattern = "COREARRAY")) {
          data.type <- "gds.file"
        } else {
          data.type <- "fst.file"
          message("This file format will be deprecated soon:")
          message("    Save to another format (e.g. parquet) or ")
          message("    Use the package fst to open and save in the future")
        }
        return(data.type)
      }

      # Arrow Parquet ----------------------------------------------------------
      if (file.ending == "quet") {
        data.type <- "arrow.parquet"
        return(data.type)
      }


      # DArT data --------------------------------------------------------------
      data.type <- detect_dart_format(data = data, verbose = FALSE) %$% data.type
      if ("dart" %in% data.type) {
      return(data.type)
      }


      if (file.ending == ".rds") {
        temp <- readRDS(file = data)
        data.type <- class(temp)[1]
        temp <- NULL
        if (!data.type %in% c("genind", "genlight", "gtypes")) {
          rlang::abort("Input file not recognised")
        }
        return(data.type)
      }
    } # end vector detection
  } #End no guess

  if (guess == "dart") {
    data.type <- detect_dart_format(data = data, verbose = FALSE)
    data.type <- data.type$data.type
    return(data.type)
  } # guess DART
  # End guess
  if (is.null(data.type)) rlang::abort("Genomic format not detected: send email to developer")
  return(data.type)
} # End detect_genomic_format

# INTERNAL functions -----------------------------------------------------------
# detect_dart_format-------------------------------------------------------------
#' @title detect_dart_format
#' @description Detect the dart genotype format: 1row, 2rows or counts
#' @rdname detect_dart_format
#' @keywords internal
#' @param verbose 
#' Default: \code{verbose = TRUE}.
#' 
#' @export
detect_dart_format <- function(data, verbose = TRUE) {
  # dart.format:
  # silico.dart
  # 1row
  # 2rows
  # counts

  # Detect how to read the file
  if (stringi::stri_detect_fixed(
    str = stringi::stri_sub(str = data, from = -4, to = -1),
    pattern = ".csv")) {
    tokenizer.dart <- ","
  } else {
    tokenizer.dart <- "\t"
  }

  # read the 1st line
  data.type <- suppressWarnings(readLines(con = data, n = 1L))

  # presence of * in the headers
  dart.headers <- TRUE %in% (stringi::stri_detect_fixed(str = data.type, pattern = c("*\t", "*,")))
  n.col <- stringi::stri_count_fixed(str = data.type, pattern = tokenizer.dart) + 1

  # deconstruct
  skip.number <- 0
  star.number <- 0

  if (dart.headers) {
    temp.file <- suppressWarnings(suppressMessages(readr::read_table(file = data, n_max = 20, col_names = "HEADER")))

    skip.number <- which(
      stringi::stri_detect_regex(str = temp.file$HEADER,pattern = "^[[:alnum:]]")
    )[1] - 1

    star.number <- stringi::stri_count_fixed(str = data.type, pattern = "*")
    data.type <- readr::read_lines(file = data, skip = skip.number, n_max = skip.number + 1)[1]
  }

  dart.clone.id <- stringi::stri_detect_fixed(str = data.type, pattern = "CloneID")
  dart.allele.id <- stringi::stri_detect_fixed(str = data.type, pattern = "AlleleID")
  dart.snp.position <- stringi::stri_detect_fixed(str = data.type, pattern = "SnpPosition")
  dart.allele.sequece <- stringi::stri_detect_fixed(str = data.type, pattern = "AlleleSequence")
  dart.markern.name <- stringi::stri_detect_fixed(str = data.type, pattern = "MarkerName")


  # DArT or not ---------
  if (dart.snp.position || dart.allele.id || dart.clone.id || dart.allele.sequece || dart.markern.name) {
    data.type <- "dart"
  } else {
    return(res = list(data.type = NULL))
  }

  # What DArT format -----
  if (dart.clone.id && !dart.allele.id) {
    dart.format <- "silico.dart"
    if (verbose) message("DArT format: silico DArT")
  } else {
    temp.line <- readr::read_lines(file = data, skip = skip.number, n_max = 1)
    dart.col <- dplyr::case_when(
      stringi::stri_detect_fixed(temp.line, "Variant") ~ "Variant",
      stringi::stri_detect_fixed(temp.line, "REF")     ~ "REF",
      stringi::stri_detect_fixed(temp.line, "SNP")     ~ "SNP",
      TRUE                                             ~ NA_character_
    )

    rows.check <- vroom::vroom(
      file = data,
      delim = tokenizer.dart,
      col_select = tidyselect::all_of(dart.col),
      skip = skip.number,
      na = c("-", "NA",""),
      guess_max = 20,
      altrep = TRUE,
      skip_empty_rows = TRUE,
      trim_ws = FALSE,
      progress = FALSE,
      show_col_types = FALSE,
      .name_repair = "minimal"
    )

    # 20250912
    # One more layer or dart flavor format...

    # one-column name (safer than trusting dart.col)
    id.col <- names(rows.check)[1]

    dup.rows <- FALSE # default
    dup.rows.na <- anyNA(rows.check[[id.col]])
    equal.rows  <- nrow(rows.check) >= 2 &&
      identical(rows.check[[id.col]][1], rows.check[[id.col]][2])
    dup.rows <- dup.rows.na || equal.rows
    rows.check <- equal.rows <- dup.rows.na <- NULL

    if (!dup.rows) {
      if (verbose) message("DArT format: genotypes in 1 Row")
      dart.format <- "1row"
    } else {
      count.data <- vroom::vroom(
        file = data,
        delim = tokenizer.dart,
        col_select = tidyselect::last_col(3):tidyselect::last_col(),
        skip = skip.number,
        n_max = 50,
        na = c("-", "NA",""),
        guess_max = 20,
        altrep = TRUE,
        skip_empty_rows = TRUE,
        trim_ws = FALSE,
        progress = FALSE,
        show_col_types = FALSE,
        .name_repair = "minimal"
      )
      count.data <- any(count.data > 1, na.rm = TRUE)

      if (count.data) {
        dart.format <- "counts"
        if (verbose) message("DArT format: alleles coverage in 2 Rows counts")
      } else {
        dart.format <- "2rows"
        if (verbose) message("DArT format: alleles absence/presence in 2 Rows")
      }
    }
  }

  # New 20250904
  # denovo or ref genome used

  # default
  ref.genome <- FALSE # default

  #20260218
  # The problem here is that dart will sometimes mix de novo and use of genome...
  # reading 20 lines is not enough to detect ...
  last20 <- read_last_lines(data, n = 20L)
  last20 <- suppressWarnings(suppressMessages(readr::read_table(I(last20), col_names = "HEADER")))
  temp.genome <- dplyr::bind_rows(last20, temp.file)
  ref.genome <- any(stringi::stri_detect_regex(str = temp.genome$HEADER, pattern = "scaffold"))

  return(
    res = list(
      data.type = data.type,
      dart.format = dart.format,
      ref.genome = ref.genome,
      skip.number = skip.number,
      star.number = star.number,
      tokenizer.dart = tokenizer.dart,
      n.col = n.col
    )
  )
}#End detect_dart_format
