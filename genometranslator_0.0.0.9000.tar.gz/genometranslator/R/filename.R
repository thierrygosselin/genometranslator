# Genomic output filename policy ----------------------------------------------
generate_filename <- function(
  name.shortcut = NULL,
  path.folder = NULL,
  date = TRUE,
  extension = c(
    "tsv", "gds.rad", "rad", "gds", "gen", "dat", "genind",
    "genlight", "gtypes", "vcf", "colony", "bayescan", "gsisim",
    "hierfstat", "hzar", "ldna", "pcadapt", "plink", "related",
    "stockr", "structure", "arlequin", "arrow.parquet"
  )
) {
  extension <- match.arg(extension)
  stem <- if (is.null(name.shortcut)) "genometranslator" else name.shortcut
  timestamp <- if (is.character(date)) date else if (isTRUE(date)) format(Sys.time(), "%Y%m%d@%H%M") else NULL
  dated <- function(x) if (is.null(timestamp)) x else paste0(x, "_", timestamp)

  spec <- switch(
    extension,
    gen = list(stem = paste0(stem, "_genepop"), extension = "gen"),
    dat = list(stem = paste0(stem, "_fstat"), extension = "dat"),
    hierfstat = list(stem = paste0(stem, "_hierfstat"), extension = "dat"),
    structure = list(stem = paste0(stem, "_structure"), extension = "str"),
    genind = list(stem = paste0(stem, "_genind"), extension = "RData"),
    genlight = list(stem = paste0(stem, "_genlight"), extension = "RData"),
    gtypes = list(stem = paste0(stem, "_gtypes"), extension = "RData"),
    stockr = list(stem = paste0(stem, "_stockr"), extension = "RData"),
    bayescan = list(stem = paste0(stem, "_bayescan"), extension = "txt"),
    pcadapt = list(stem = paste0(stem, "_pcadapt"), extension = "txt"),
    related = list(stem = paste0(stem, "_related"), extension = "txt"),
    hzar = list(stem = paste0(stem, "_hzar"), extension = "csv"),
    arlequin = list(stem = paste0(stem, "_arlequin"), extension = "csv"),
    list(stem = stem, extension = extension)
  )

  tgbase::build_filename(
    stem = dated(spec$stem),
    extension = spec$extension,
    path.folder = path.folder,
    date = FALSE,
    create = TRUE
  )
}
